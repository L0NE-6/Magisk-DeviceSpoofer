#!/system/bin/sh
# 还原 OPPO K11 机型伪装（Android 1.x-5.x 手动模式）
# 用法（需要 root）：su -c 'sh /sdcard/xj_restore.sh'

BP=/system/build.prop
mount -o rw,remount /system 2>/dev/null
if [ ! -f "$BP.xj_bak" ]; then
	echo "[!] 未找到备份 $BP.xj_bak"
	exit 1
fi
cat "$BP.xj_bak" > "$BP"
rm -f "$BP.xj_bak"
sync 2>/dev/null
echo "[+] 已还原，重启后生效"