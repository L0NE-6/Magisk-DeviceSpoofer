# OPPO A9x 机型伪装（Android 1-17 适配版）

- 目标机型: OPPO A9x
- 型号号: PCEM00
- 代号: pcem00
- 品牌: OPPO (manufacturer=OPPO)
- 模块 id: xj_pcem00

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 PCEM00，getprop ro.product.marketname 应为 OPPO A9x。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| PCEM00 | OPPO A9x 全网通版 |
| PCET00 | OPPO A9x 移动版 |