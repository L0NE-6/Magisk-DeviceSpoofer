# OPPO F17 Pro 机型伪装（Android 1-17 适配版）

- 目标机型: OPPO F17 Pro
- 型号号: CPH2119
- 代号: cph2119
- 品牌: OPPO (manufacturer=OPPO)
- 模块 id: xj_cph2119

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 CPH2119，getprop ro.product.marketname 应为 OPPO F17 Pro。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| CPH2119 | OPPO F17 Pro |