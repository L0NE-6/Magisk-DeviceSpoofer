#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "realme"
	set_prop "ro.product.system.brand" "realme"
	set_prop "ro.product.system.marketname" "realme P4 Lite"
	set_prop "ro.product.system.model" "RMX5377"
	set_prop "ro.product.system.name" "nairobi-a"
	set_prop "ro.product.system_ext.manufacturer" "realme"
	set_prop "ro.product.system_ext.brand" "realme"
	set_prop "ro.product.system_ext.marketname" "realme P4 Lite"
	set_prop "ro.product.system_ext.model" "RMX5377"
	set_prop "ro.product.system_ext.name" "nairobi-a"
	set_prop "ro.product.vendor.manufacturer" "realme"
	set_prop "ro.product.vendor.brand" "realme"
	set_prop "ro.product.vendor.marketname" "realme P4 Lite"
	set_prop "ro.product.vendor.model" "RMX5377"
	set_prop "ro.product.vendor.name" "nairobi-a"
	set_prop "ro.product.product.manufacturer" "realme"
	set_prop "ro.product.product.brand" "realme"
	set_prop "ro.product.product.marketname" "realme P4 Lite"
	set_prop "ro.product.product.model" "RMX5377"
	set_prop "ro.product.product.name" "nairobi-a"
	set_prop "ro.product.odm.manufacturer" "realme"
	set_prop "ro.product.odm.brand" "realme"
	set_prop "ro.product.odm.marketname" "realme P4 Lite"
	set_prop "ro.product.odm.model" "RMX5377"
	set_prop "ro.product.odm.name" "nairobi-a"
	set_prop "ro.product.bootimage.manufacturer" "realme"
	set_prop "ro.product.bootimage.brand" "realme"
	set_prop "ro.product.bootimage.marketname" "realme P4 Lite"
	set_prop "ro.product.bootimage.model" "RMX5377"
	set_prop "ro.product.bootimage.name" "nairobi-a"
	set_prop "ro.product.vendor_dlkm.manufacturer" "realme"
	set_prop "ro.product.vendor_dlkm.brand" "realme"
	set_prop "ro.product.vendor_dlkm.marketname" "realme P4 Lite"
	set_prop "ro.product.vendor_dlkm.model" "RMX5377"
	set_prop "ro.product.vendor_dlkm.name" "nairobi-a"
	set_prop "ro.product.odm_dlkm.manufacturer" "realme"
	set_prop "ro.product.odm_dlkm.brand" "realme"
	set_prop "ro.product.odm_dlkm.marketname" "realme P4 Lite"
	set_prop "ro.product.odm_dlkm.model" "RMX5377"
	set_prop "ro.product.odm_dlkm.name" "nairobi-a"
set_prop ro.product.manufacturer realme
set_prop ro.product.brand realme
set_prop ro.product.marketname "realme P4 Lite"
set_prop ro.product.model RMX5377
set_prop ro.product.name nairobi-a