# Xperia 10 III 机型伪装（Android 1-17 适配版）

- 目标机型: Xperia 10 III
- 型号号: XQ-BT44
- 代号: PDX-213
- 品牌: Sony (manufacturer=Sony)
- 模块 id: xj_pdx-213

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 XQ-BT44，getprop ro.product.marketname 应为 Xperia 10 III。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| XQ-BT44 | Xperia 10 III Japan (SIM Free) |
| XQ-BT52 | Xperia 10 III Global |
| A102SO | Xperia 10 III Japan (SoftBank) |
| SO-52B | Xperia 10 III Japan (NTT Docomo) |
| SOG04 | Xperia 10 III Japan (KDDI) |