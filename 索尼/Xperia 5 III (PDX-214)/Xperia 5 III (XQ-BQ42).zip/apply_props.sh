#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "Sony"
	set_prop "ro.product.system.brand" "Sony"
	set_prop "ro.product.system.marketname" "Xperia 5 III"
	set_prop "ro.product.system.model" "XQ-BQ42"
	set_prop "ro.product.system.name" "PDX-214"
	set_prop "ro.product.system_ext.manufacturer" "Sony"
	set_prop "ro.product.system_ext.brand" "Sony"
	set_prop "ro.product.system_ext.marketname" "Xperia 5 III"
	set_prop "ro.product.system_ext.model" "XQ-BQ42"
	set_prop "ro.product.system_ext.name" "PDX-214"
	set_prop "ro.product.vendor.manufacturer" "Sony"
	set_prop "ro.product.vendor.brand" "Sony"
	set_prop "ro.product.vendor.marketname" "Xperia 5 III"
	set_prop "ro.product.vendor.model" "XQ-BQ42"
	set_prop "ro.product.vendor.name" "PDX-214"
	set_prop "ro.product.product.manufacturer" "Sony"
	set_prop "ro.product.product.brand" "Sony"
	set_prop "ro.product.product.marketname" "Xperia 5 III"
	set_prop "ro.product.product.model" "XQ-BQ42"
	set_prop "ro.product.product.name" "PDX-214"
	set_prop "ro.product.odm.manufacturer" "Sony"
	set_prop "ro.product.odm.brand" "Sony"
	set_prop "ro.product.odm.marketname" "Xperia 5 III"
	set_prop "ro.product.odm.model" "XQ-BQ42"
	set_prop "ro.product.odm.name" "PDX-214"
	set_prop "ro.product.bootimage.manufacturer" "Sony"
	set_prop "ro.product.bootimage.brand" "Sony"
	set_prop "ro.product.bootimage.marketname" "Xperia 5 III"
	set_prop "ro.product.bootimage.model" "XQ-BQ42"
	set_prop "ro.product.bootimage.name" "PDX-214"
	set_prop "ro.product.vendor_dlkm.manufacturer" "Sony"
	set_prop "ro.product.vendor_dlkm.brand" "Sony"
	set_prop "ro.product.vendor_dlkm.marketname" "Xperia 5 III"
	set_prop "ro.product.vendor_dlkm.model" "XQ-BQ42"
	set_prop "ro.product.vendor_dlkm.name" "PDX-214"
	set_prop "ro.product.odm_dlkm.manufacturer" "Sony"
	set_prop "ro.product.odm_dlkm.brand" "Sony"
	set_prop "ro.product.odm_dlkm.marketname" "Xperia 5 III"
	set_prop "ro.product.odm_dlkm.model" "XQ-BQ42"
	set_prop "ro.product.odm_dlkm.name" "PDX-214"
set_prop ro.product.manufacturer Sony
set_prop ro.product.brand Sony
set_prop ro.product.marketname "Xperia 5 III"
set_prop ro.product.model XQ-BQ42
set_prop ro.product.name PDX-214