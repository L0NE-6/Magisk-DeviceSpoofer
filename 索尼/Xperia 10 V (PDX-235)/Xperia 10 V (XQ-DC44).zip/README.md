# Xperia 10 V 机型伪装（Android 1-17 适配版）

- 目标机型: Xperia 10 V
- 型号号: XQ-DC44
- 代号: PDX-235
- 品牌: Sony (manufacturer=Sony)
- 模块 id: xj_pdx-235

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 XQ-DC44，getprop ro.product.marketname 应为 Xperia 10 V。

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| XQ-DC44 | Xperia 10 V Japan (SIM Free) |
| XQ-DC54 | Xperia 10 V Global |
| XQ-DC72 | Xperia 10 V Asia Pacific |
| A302SO | Xperia 10 V Japan (SoftBank) |
| SO-52D | Xperia 10 V Japan (NTT Docomo) |
| SOG11 | Xperia 10 V Japan (KDDI) |