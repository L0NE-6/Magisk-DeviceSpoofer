# Galaxy S24 FE 机型伪装（Android 1-17 适配版）

- 目标机型: Galaxy S24 FE
- 型号号: SM-S721B
- 代号: r12s
- 品牌: samsung (manufacturer=samsung)
- 模块 id: xj_r12s

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 SM-S721B，getprop ro.product.marketname 应为 Galaxy S24 FE。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| SM-S721B | Galaxy S24 FE Global |
| SM-S721U | Galaxy S24 FE US Carrier |
| SM-S721U1 | Galaxy S24 FE US Unlocked |
| SM-S721W | Galaxy S24 FE Canada |
| SM-S7210 | Galaxy S24 FE HK & TW |
| SM-S721Q | Galaxy S24 FE Japan (SIM Free) |
| SCG30 | Galaxy S24 FE Japan (au) |
| SM-S721N | Galaxy S24 FE South Korea |