# Galaxy A35 5G 机型伪装（Android 1-17 适配版）

- 目标机型: Galaxy A35 5G
- 型号号: SM-A356E
- 代号: a35x
- 品牌: samsung (manufacturer=samsung)
- 模块 id: xj_a35x

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 SM-A356E，getprop ro.product.marketname 应为 Galaxy A35 5G。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| SM-A356E | Galaxy A35 5G Global |
| SM-A356B | Galaxy A35 5G EU |
| SM-A356U | Galaxy A35 5G US Carrier |
| SM-A356U1 | Galaxy A35 5G US Unlocked |
| SM-S356V | Galaxy A35 5G TracFone |
| SM-A356W | Galaxy A35 5G Canada |
| SM-A3560 | Galaxy A35 5G HK & TW |
| SM-A356N | Galaxy A35 5G South Korea |