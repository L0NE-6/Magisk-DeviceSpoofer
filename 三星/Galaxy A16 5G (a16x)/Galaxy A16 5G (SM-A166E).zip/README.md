# Galaxy A16 5G 机型伪装（Android 1-17 适配版）

- 目标机型: Galaxy A16 5G
- 型号号: SM-A166E
- 代号: a16x
- 品牌: samsung (manufacturer=samsung)
- 模块 id: xj_a16x

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 SM-A166E，getprop ro.product.marketname 应为 Galaxy A16 5G。

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| SM-A166E | Galaxy A16 5G Global (Exynos) |
| SM-A166B | Galaxy A16 5G EU |
| SM-A166U | Galaxy A16 5G US Carrier |
| SM-A166U1 | Galaxy A16 5G US Unlocked |
| SM-S166V | Galaxy A16 5G TracFone |
| SM-A166W | Galaxy A16 5G Canada |
| SM-A166M | Galaxy A16 5G Latin America |
| SM-A1660 | Galaxy A16 5G HK & TW |