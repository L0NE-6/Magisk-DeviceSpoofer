#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "samsung"
	set_prop "ro.product.system.brand" "samsung"
	set_prop "ro.product.system.marketname" "三星 W27"
	set_prop "ro.product.system.model" "SM-W9027"
	set_prop "ro.product.system.name" "q8q"
	set_prop "ro.product.system_ext.manufacturer" "samsung"
	set_prop "ro.product.system_ext.brand" "samsung"
	set_prop "ro.product.system_ext.marketname" "三星 W27"
	set_prop "ro.product.system_ext.model" "SM-W9027"
	set_prop "ro.product.system_ext.name" "q8q"
	set_prop "ro.product.vendor.manufacturer" "samsung"
	set_prop "ro.product.vendor.brand" "samsung"
	set_prop "ro.product.vendor.marketname" "三星 W27"
	set_prop "ro.product.vendor.model" "SM-W9027"
	set_prop "ro.product.vendor.name" "q8q"
	set_prop "ro.product.product.manufacturer" "samsung"
	set_prop "ro.product.product.brand" "samsung"
	set_prop "ro.product.product.marketname" "三星 W27"
	set_prop "ro.product.product.model" "SM-W9027"
	set_prop "ro.product.product.name" "q8q"
	set_prop "ro.product.odm.manufacturer" "samsung"
	set_prop "ro.product.odm.brand" "samsung"
	set_prop "ro.product.odm.marketname" "三星 W27"
	set_prop "ro.product.odm.model" "SM-W9027"
	set_prop "ro.product.odm.name" "q8q"
	set_prop "ro.product.bootimage.manufacturer" "samsung"
	set_prop "ro.product.bootimage.brand" "samsung"
	set_prop "ro.product.bootimage.marketname" "三星 W27"
	set_prop "ro.product.bootimage.model" "SM-W9027"
	set_prop "ro.product.bootimage.name" "q8q"
	set_prop "ro.product.vendor_dlkm.manufacturer" "samsung"
	set_prop "ro.product.vendor_dlkm.brand" "samsung"
	set_prop "ro.product.vendor_dlkm.marketname" "三星 W27"
	set_prop "ro.product.vendor_dlkm.model" "SM-W9027"
	set_prop "ro.product.vendor_dlkm.name" "q8q"
	set_prop "ro.product.odm_dlkm.manufacturer" "samsung"
	set_prop "ro.product.odm_dlkm.brand" "samsung"
	set_prop "ro.product.odm_dlkm.marketname" "三星 W27"
	set_prop "ro.product.odm_dlkm.model" "SM-W9027"
	set_prop "ro.product.odm_dlkm.name" "q8q"
set_prop ro.product.manufacturer samsung
set_prop ro.product.brand samsung
set_prop ro.product.marketname "三星 W27"
set_prop ro.product.model SM-W9027
set_prop ro.product.name q8q