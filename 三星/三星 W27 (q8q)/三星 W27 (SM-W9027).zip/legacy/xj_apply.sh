#!/system/bin/sh
# 三星 W27 机型伪装（Android 1.x-5.x 手动模式）
# 用法（需要 root）：su -c 'sh /sdcard/xj_apply.sh'
# 自动备份为 /system/build.prop.xj_bak，重复执行安全

BP=/system/build.prop
echo "[*] 机型伪装 -> 三星 W27 (SM-W9027)"

mount -o rw,remount /system 2>/dev/null
[ -f "$BP" ] || mount /system 2>/dev/null
if [ ! -f "$BP" ]; then
	echo "[!] 找不到 $BP（无法挂载 /system）"
	exit 1
fi
touch /system/.xj_write_test 2>/dev/null
if [ ! -f /system/.xj_write_test ]; then
	echo "[!] /system 只读，无法修改"
	exit 1
fi
rm -f /system/.xj_write_test

[ -f "$BP.xj_bak" ] || cp -f "$BP" "$BP.xj_bak"

while IFS= read -r line; do
	case "$line" in
		ro.product.brand=*|ro.product.manufacturer=*|ro.product.model=*|ro.product.name=*|ro.product.marketname=*) ;;
		*) echo "$line" ;;
	esac
done < "$BP" > "$BP.xj_tmp"
if [ ! -s "$BP.xj_tmp" ]; then
	rm -f "$BP.xj_tmp"
	echo "[!] 处理失败，未做修改"
	exit 1
fi
{
	cat "$BP.xj_tmp"
	echo "ro.product.brand=samsung"
	echo "ro.product.manufacturer=samsung"
	echo "ro.product.model=SM-W9027"
	echo "ro.product.name=q8q"
	echo "ro.product.marketname=三星 W27"
} > "$BP.xj_new"
cat "$BP.xj_new" > "$BP"
rm -f "$BP.xj_tmp" "$BP.xj_new"
sync 2>/dev/null
echo "[+] 完成，重启后生效；备份：$BP.xj_bak"