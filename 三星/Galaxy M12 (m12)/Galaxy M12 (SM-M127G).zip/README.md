# Galaxy M12 机型伪装（Android 1-17 适配版）

- 目标机型: Galaxy M12
- 型号号: SM-M127G
- 代号: m12
- 品牌: samsung (manufacturer=samsung)
- 模块 id: xj_m12

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 SM-M127G，getprop ro.product.marketname 应为 Galaxy M12。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| SM-M127G | Galaxy M12 India |
| SM-M127F | Galaxy M12 Latin America |
| SM-M127N | Galaxy M12 South Korea |