# Galaxy A20 机型伪装（Android 1-17 适配版）

- 目标机型: Galaxy A20
- 型号号: SM-A205F
- 代号: a20
- 品牌: samsung (manufacturer=samsung)
- 模块 id: xj_a20

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 SM-A205F，getprop ro.product.marketname 应为 Galaxy A20。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| SM-A205F | Galaxy A20 Global |
| SM-A205FN | Galaxy A20 EU |
| SM-A205G | Galaxy A20 Latin America |
| SM-A205GN | Galaxy A20 Southeast Asia |
| SM-A205W | Galaxy A20 Canada |
| SM-A205YN | Galaxy A20 Australia & New Zealand |
| SCV46 | Galaxy A20 Japan (au) |
| SC-02M | Galaxy A20 Japan (NTT Docomo) |