# Galaxy A02s 机型伪装（Android 1-17 适配版）

- 目标机型: Galaxy A02s
- 型号号: SM-A025F
- 代号: a02q
- 品牌: samsung (manufacturer=samsung)
- 模块 id: xj_a02q

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

getprop ro.product.model 应为 SM-A025F，getprop ro.product.marketname 应为 Galaxy A02s。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| SM-A025F | Galaxy A02s Global |
| SM-A025G | Galaxy A02s EU |
| SM-A025U | Galaxy A02s US Carrier |
| SM-A025U1 | Galaxy A02s US Unlocked |
| SM-A025A | Galaxy A02s AT&T |
| SM-A025AZ | Galaxy A02s Cricket |
| SM-A025V | Galaxy A02s Verizon |
| SM-S124DL | Galaxy A02s TracFone |
| SM-A025M | Galaxy A02s Latin America |