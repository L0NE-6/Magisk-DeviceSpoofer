# Galaxy A23 5G 机型伪装（Android 1-17 适配版）

- 目标机型: Galaxy A23 5G
- 型号号: SM-A235E
- 代号: a23xq
- 品牌: samsung (manufacturer=samsung)
- 模块 id: xj_a23xq

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 SM-A235E，getprop ro.product.marketname 应为 Galaxy A23 5G。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| SM-A235E | Galaxy A23 5G Global |
| SM-A236B | Galaxy A23 5G EU |
| SM-A236U | Galaxy A23 5G US Carrier |
| SM-A236U1 | Galaxy A23 5G US Unlocked |
| SM-A236V | Galaxy A23 5G UW Verizon |
| SM-A236M | Galaxy A23 5G Latin America |
| SM-A2360 | Galaxy A23 5G HK |
| SCG18 | Galaxy A23 5G Japan (au) |
| SC-56C | Galaxy A23 5G Japan (NTT Docomo) |