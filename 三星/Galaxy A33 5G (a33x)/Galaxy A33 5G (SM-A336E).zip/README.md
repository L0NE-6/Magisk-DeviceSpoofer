# Galaxy A33 5G 机型伪装（Android 1-17 适配版）

- 目标机型: Galaxy A33 5G
- 型号号: SM-A336E
- 代号: a33x
- 品牌: samsung (manufacturer=samsung)
- 模块 id: xj_a33x

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 SM-A336E，getprop ro.product.marketname 应为 Galaxy A33 5G。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| SM-A336E | Galaxy A33 5G Global |
| SM-A336B | Galaxy A33 5G EU |
| SM-A336M | Galaxy A33 5G Latin America |
| SM-A3360 | Galaxy A33 5G HK |
| SM-A336N | Galaxy A33 5G South Korea |