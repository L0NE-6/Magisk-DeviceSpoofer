# Galaxy A50 机型伪装（Android 1-17 适配版）

- 目标机型: Galaxy A50
- 型号号: SM-A505F
- 代号: a50
- 品牌: samsung (manufacturer=samsung)
- 模块 id: xj_a50

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 SM-A505F，getprop ro.product.marketname 应为 Galaxy A50。

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| SM-A505F | Galaxy A50 Global |
| SM-A505FN | Galaxy A50 EU |
| SM-A505FM | Galaxy A50 Russia |
| SM-A505G | Galaxy A50 Latin America |
| SM-A505GN | Galaxy A50 Southeast Asia |
| SM-A505GT | Galaxy A50 Brazil |
| SM-A505U | Galaxy A50 US Carrier |
| SM-A505U1 | Galaxy A50 US Unlocked |
| SM-S506DL | Galaxy A50 TracFone |
| SM-A505W | Galaxy A50 Canada |
| SM-A505N | Galaxy A50 South Korea |
| SM-A505YN | Galaxy A50 Australia & New Zealand |