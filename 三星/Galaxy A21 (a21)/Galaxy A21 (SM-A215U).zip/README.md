# Galaxy A21 机型伪装（Android 1-17 适配版）

- 目标机型: Galaxy A21
- 型号号: SM-A215U
- 代号: a21
- 品牌: samsung (manufacturer=samsung)
- 模块 id: xj_a21

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

getprop ro.product.model 应为 SM-A215U，getprop ro.product.marketname 应为 Galaxy A21。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| SM-A215U | Galaxy A21 US Carrier |
| SM-A215U1 | Galaxy A21 US Unlocked |
| SM-S215DL | Galaxy A21 TracFone |
| SM-A215W | Galaxy A21 Canada |
| SCV49 | Galaxy A21 Japan (au) |
| SC-42A | Galaxy A21 Japan (NTT Docomo) |