# Galaxy A14 5G 机型伪装（Android 1-17 适配版）

- 目标机型: Galaxy A14 5G
- 型号号: SM-A146P
- 代号: a14xm
- 品牌: samsung (manufacturer=samsung)
- 模块 id: xj_a14xm

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 SM-A146P，getprop ro.product.marketname 应为 Galaxy A14 5G。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| SM-A146P | Galaxy A14 5G Global (MediaTek) |
| SM-A146U | Galaxy A14 5G US Carrier |
| SM-A146U1 | Galaxy A14 5G US Unlocked |
| SM-S146VL | Galaxy A14 5G TracFone |
| SM-A146W | Galaxy A14 5G Canada |