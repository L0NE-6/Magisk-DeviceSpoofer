# Smartisan TNT go 机型伪装（Android 1-17 适配版）

- 目标机型: Smartisan TNT go
- 型号号: DT2003A
- 代号: dt2003a
- 品牌: smartisan (manufacturer=Smartisan)
- 模块 id: xj_dt2003a

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 DT2003A，getprop ro.product.marketname 应为 Smartisan TNT go。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| DT2003A | Smartisan TNT go 有线版 |
| DT2003C | Smartisan TNT go 无线版 |