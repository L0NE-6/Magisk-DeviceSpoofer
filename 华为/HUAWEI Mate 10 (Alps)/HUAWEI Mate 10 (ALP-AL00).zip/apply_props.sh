#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "HUAWEI"
	set_prop "ro.product.system.brand" "HUAWEI"
	set_prop "ro.product.system.marketname" "HUAWEI Mate 10"
	set_prop "ro.product.system.model" "ALP-AL00"
	set_prop "ro.product.system.name" "Alps"
	set_prop "ro.product.system_ext.manufacturer" "HUAWEI"
	set_prop "ro.product.system_ext.brand" "HUAWEI"
	set_prop "ro.product.system_ext.marketname" "HUAWEI Mate 10"
	set_prop "ro.product.system_ext.model" "ALP-AL00"
	set_prop "ro.product.system_ext.name" "Alps"
	set_prop "ro.product.vendor.manufacturer" "HUAWEI"
	set_prop "ro.product.vendor.brand" "HUAWEI"
	set_prop "ro.product.vendor.marketname" "HUAWEI Mate 10"
	set_prop "ro.product.vendor.model" "ALP-AL00"
	set_prop "ro.product.vendor.name" "Alps"
	set_prop "ro.product.product.manufacturer" "HUAWEI"
	set_prop "ro.product.product.brand" "HUAWEI"
	set_prop "ro.product.product.marketname" "HUAWEI Mate 10"
	set_prop "ro.product.product.model" "ALP-AL00"
	set_prop "ro.product.product.name" "Alps"
	set_prop "ro.product.odm.manufacturer" "HUAWEI"
	set_prop "ro.product.odm.brand" "HUAWEI"
	set_prop "ro.product.odm.marketname" "HUAWEI Mate 10"
	set_prop "ro.product.odm.model" "ALP-AL00"
	set_prop "ro.product.odm.name" "Alps"
	set_prop "ro.product.bootimage.manufacturer" "HUAWEI"
	set_prop "ro.product.bootimage.brand" "HUAWEI"
	set_prop "ro.product.bootimage.marketname" "HUAWEI Mate 10"
	set_prop "ro.product.bootimage.model" "ALP-AL00"
	set_prop "ro.product.bootimage.name" "Alps"
	set_prop "ro.product.vendor_dlkm.manufacturer" "HUAWEI"
	set_prop "ro.product.vendor_dlkm.brand" "HUAWEI"
	set_prop "ro.product.vendor_dlkm.marketname" "HUAWEI Mate 10"
	set_prop "ro.product.vendor_dlkm.model" "ALP-AL00"
	set_prop "ro.product.vendor_dlkm.name" "Alps"
	set_prop "ro.product.odm_dlkm.manufacturer" "HUAWEI"
	set_prop "ro.product.odm_dlkm.brand" "HUAWEI"
	set_prop "ro.product.odm_dlkm.marketname" "HUAWEI Mate 10"
	set_prop "ro.product.odm_dlkm.model" "ALP-AL00"
	set_prop "ro.product.odm_dlkm.name" "Alps"
set_prop ro.product.manufacturer HUAWEI
set_prop ro.product.brand HUAWEI
set_prop ro.product.marketname "HUAWEI Mate 10"
set_prop ro.product.model ALP-AL00
set_prop ro.product.name Alps