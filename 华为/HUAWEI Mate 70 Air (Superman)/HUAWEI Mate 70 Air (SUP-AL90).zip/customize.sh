#!/system/bin/sh
# 新式模块安装回调：Magisk / KernelSU / APatch 通用

ui_print " -------------------------- "
ui_print "  HUAWEI Mate 70 Air 机型伪装"
ui_print "  Android 1-17 适配版"
ui_print " -------------------------- "

for f in apply_props.sh post-fs-data.sh service.sh; do
	[ -f "$MODPATH/$f" ] && set_perm "$MODPATH/$f" 0 0 0755
done
[ -f "$MODPATH/system.prop" ] && set_perm "$MODPATH/system.prop" 0 0 0644
[ -f "$MODPATH/module.prop" ] && set_perm "$MODPATH/module.prop" 0 0 0644

ui_print " - 安装完成，重启后生效"
ui_print " - 如已装旧版机型模块，请先卸载旧版"
ui_print " -------------------------- "