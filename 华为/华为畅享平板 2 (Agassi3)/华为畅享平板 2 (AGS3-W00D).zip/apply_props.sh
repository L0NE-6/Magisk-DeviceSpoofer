#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "HUAWEI"
	set_prop "ro.product.system.brand" "HUAWEI"
	set_prop "ro.product.system.marketname" "华为畅享平板 2"
	set_prop "ro.product.system.model" "AGS3-W00D"
	set_prop "ro.product.system.name" "Agassi3"
	set_prop "ro.product.system_ext.manufacturer" "HUAWEI"
	set_prop "ro.product.system_ext.brand" "HUAWEI"
	set_prop "ro.product.system_ext.marketname" "华为畅享平板 2"
	set_prop "ro.product.system_ext.model" "AGS3-W00D"
	set_prop "ro.product.system_ext.name" "Agassi3"
	set_prop "ro.product.vendor.manufacturer" "HUAWEI"
	set_prop "ro.product.vendor.brand" "HUAWEI"
	set_prop "ro.product.vendor.marketname" "华为畅享平板 2"
	set_prop "ro.product.vendor.model" "AGS3-W00D"
	set_prop "ro.product.vendor.name" "Agassi3"
	set_prop "ro.product.product.manufacturer" "HUAWEI"
	set_prop "ro.product.product.brand" "HUAWEI"
	set_prop "ro.product.product.marketname" "华为畅享平板 2"
	set_prop "ro.product.product.model" "AGS3-W00D"
	set_prop "ro.product.product.name" "Agassi3"
	set_prop "ro.product.odm.manufacturer" "HUAWEI"
	set_prop "ro.product.odm.brand" "HUAWEI"
	set_prop "ro.product.odm.marketname" "华为畅享平板 2"
	set_prop "ro.product.odm.model" "AGS3-W00D"
	set_prop "ro.product.odm.name" "Agassi3"
	set_prop "ro.product.bootimage.manufacturer" "HUAWEI"
	set_prop "ro.product.bootimage.brand" "HUAWEI"
	set_prop "ro.product.bootimage.marketname" "华为畅享平板 2"
	set_prop "ro.product.bootimage.model" "AGS3-W00D"
	set_prop "ro.product.bootimage.name" "Agassi3"
	set_prop "ro.product.vendor_dlkm.manufacturer" "HUAWEI"
	set_prop "ro.product.vendor_dlkm.brand" "HUAWEI"
	set_prop "ro.product.vendor_dlkm.marketname" "华为畅享平板 2"
	set_prop "ro.product.vendor_dlkm.model" "AGS3-W00D"
	set_prop "ro.product.vendor_dlkm.name" "Agassi3"
	set_prop "ro.product.odm_dlkm.manufacturer" "HUAWEI"
	set_prop "ro.product.odm_dlkm.brand" "HUAWEI"
	set_prop "ro.product.odm_dlkm.marketname" "华为畅享平板 2"
	set_prop "ro.product.odm_dlkm.model" "AGS3-W00D"
	set_prop "ro.product.odm_dlkm.name" "Agassi3"
set_prop ro.product.manufacturer HUAWEI
set_prop ro.product.brand HUAWEI
set_prop ro.product.marketname "华为畅享平板 2"
set_prop ro.product.model AGS3-W00D
set_prop ro.product.name Agassi3