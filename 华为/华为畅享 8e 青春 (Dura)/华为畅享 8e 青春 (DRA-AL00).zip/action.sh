#!/system/bin/sh
# 打开作者酷安主页：装有酷安 App 直接跳转，未安装则用浏览器打开
# （KernelSU / APatch 管理器：模块卡片「执行 / Action」按钮）

/system/bin/am start -a android.intent.action.VIEW -d "coolapk://u/1429422" >/dev/null 2>&1 || \
/system/bin/am start -a android.intent.action.VIEW -d "https://www.coolapk.com/u/1429422" >/dev/null 2>&1