# 华为 Ascend P7 机型伪装（Android 1-17 适配版）

- 目标机型: 华为 Ascend P7
- 型号号: HUAWEI P7-L00
- 代号: Sophia
- 品牌: HUAWEI (manufacturer=HUAWEI)
- 模块 id: xj_sophia

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 HUAWEI P7-L00，getprop ro.product.marketname 应为 华为 Ascend P7。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| HUAWEI P7-L00 | 华为 Ascend P7 联通版 |
| HUAWEI P7-L05 | 华为 Ascend P7 移动渠道版 |
| HUAWEI P7-L07 | 华为 Ascend P7 移动定制版 |
| HUAWEI P7-L09 | 华为 Ascend P7 电信版 |