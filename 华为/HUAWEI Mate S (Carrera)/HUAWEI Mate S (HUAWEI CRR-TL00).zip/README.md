# HUAWEI Mate S 机型伪装（Android 1-17 适配版）

- 目标机型: HUAWEI Mate S
- 型号号: HUAWEI CRR-TL00
- 代号: Carrera
- 品牌: HUAWEI (manufacturer=HUAWEI)
- 模块 id: xj_carrera

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 HUAWEI CRR-TL00，getprop ro.product.marketname 应为 HUAWEI Mate S。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| HUAWEI CRR-TL00 | HUAWEI Mate S 移动臻享版 |
| HUAWEI CRR-UL00 | HUAWEI Mate S 双 4G 臻享版 |
| HUAWEI CRR-UL20 | HUAWEI Mate S 双 4G 臻逸版 |
| HUAWEI CRR-CL00 | HUAWEI Mate S 电信臻享版 |
| HUAWEI CRR-CL20 | HUAWEI Mate S 电信臻逸版 |