# vivo S1 Pro 机型伪装（Android 1-17 适配版）

- 目标机型: vivo S1 Pro
- 型号号: V1832A
- 代号: PD1832
- 品牌: vivo (manufacturer=vivo)
- 模块 id: xj_pd1832

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 V1832A，getprop ro.product.marketname 应为 vivo S1 Pro。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| V1832A | vivo S1 Pro 全网通版 |
| V1832T | vivo S1 Pro 移动全网通版 |