# vivo X100 Pro 机型伪装（Android 1-17 适配版）

- 目标机型: vivo X100 Pro
- 型号号: V2324A
- 代号: PD2324
- 品牌: vivo (manufacturer=vivo)
- 模块 id: xj_pd2324

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

getprop ro.product.model 应为 V2324A，getprop ro.product.marketname 应为 vivo X100 Pro。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| V2324A | vivo X100 Pro |