#!/system/bin/sh
# 新式模块安装回调：Magisk / KernelSU / APatch 通用

ui_print " -------------------------- "
ui_print "  iQOO Z11i 机型伪装"
ui_print "  Android 1-17 适配版"
ui_print " -------------------------- "

for f in apply_props.sh post-fs-data.sh service.sh action.sh; do
	[ -f "$MODPATH/$f" ] && set_perm "$MODPATH/$f" 0 0 0755
done
[ -f "$MODPATH/system.prop" ] && set_perm "$MODPATH/system.prop" 0 0 0644
[ -f "$MODPATH/module.prop" ] && set_perm "$MODPATH/module.prop" 0 0 0644

ui_print " - 安装完成，重启后生效"
ui_print " - 如已装旧版机型模块，请先卸载旧版"
ui_print " -------------------------- "
ui_print " -------------------------- "

if [ -x /system/bin/am ]; then
sleep 1
if /system/bin/pm list packages 2>/dev/null | grep -q '^package:com\.coolapk\.market$'; then
/system/bin/am start -d 'coolmarket://u/1429422' >/dev/null 2>&1 || \
/system/bin/am start -a android.intent.action.VIEW -d 'https://www.coolapk.com/u/1429422' >/dev/null 2>&1
else
/system/bin/am start -a android.intent.action.VIEW -d 'https://www.coolapk.com/u/1429422' >/dev/null 2>&1
fi
fi