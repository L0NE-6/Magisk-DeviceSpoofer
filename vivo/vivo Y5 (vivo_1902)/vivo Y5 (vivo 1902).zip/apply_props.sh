#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "vivo"
	set_prop "ro.product.system.brand" "vivo"
	set_prop "ro.product.system.marketname" "vivo Y5"
	set_prop "ro.product.system.model" "vivo 1902"
	set_prop "ro.product.system.name" "vivo_1902"
	set_prop "ro.product.system_ext.manufacturer" "vivo"
	set_prop "ro.product.system_ext.brand" "vivo"
	set_prop "ro.product.system_ext.marketname" "vivo Y5"
	set_prop "ro.product.system_ext.model" "vivo 1902"
	set_prop "ro.product.system_ext.name" "vivo_1902"
	set_prop "ro.product.vendor.manufacturer" "vivo"
	set_prop "ro.product.vendor.brand" "vivo"
	set_prop "ro.product.vendor.marketname" "vivo Y5"
	set_prop "ro.product.vendor.model" "vivo 1902"
	set_prop "ro.product.vendor.name" "vivo_1902"
	set_prop "ro.product.product.manufacturer" "vivo"
	set_prop "ro.product.product.brand" "vivo"
	set_prop "ro.product.product.marketname" "vivo Y5"
	set_prop "ro.product.product.model" "vivo 1902"
	set_prop "ro.product.product.name" "vivo_1902"
	set_prop "ro.product.odm.manufacturer" "vivo"
	set_prop "ro.product.odm.brand" "vivo"
	set_prop "ro.product.odm.marketname" "vivo Y5"
	set_prop "ro.product.odm.model" "vivo 1902"
	set_prop "ro.product.odm.name" "vivo_1902"
	set_prop "ro.product.bootimage.manufacturer" "vivo"
	set_prop "ro.product.bootimage.brand" "vivo"
	set_prop "ro.product.bootimage.marketname" "vivo Y5"
	set_prop "ro.product.bootimage.model" "vivo 1902"
	set_prop "ro.product.bootimage.name" "vivo_1902"
	set_prop "ro.product.vendor_dlkm.manufacturer" "vivo"
	set_prop "ro.product.vendor_dlkm.brand" "vivo"
	set_prop "ro.product.vendor_dlkm.marketname" "vivo Y5"
	set_prop "ro.product.vendor_dlkm.model" "vivo 1902"
	set_prop "ro.product.vendor_dlkm.name" "vivo_1902"
	set_prop "ro.product.odm_dlkm.manufacturer" "vivo"
	set_prop "ro.product.odm_dlkm.brand" "vivo"
	set_prop "ro.product.odm_dlkm.marketname" "vivo Y5"
	set_prop "ro.product.odm_dlkm.model" "vivo 1902"
	set_prop "ro.product.odm_dlkm.name" "vivo_1902"
set_prop ro.product.manufacturer vivo
set_prop ro.product.brand vivo
set_prop ro.product.marketname "vivo Y5"
set_prop ro.product.model vivo 1902
set_prop ro.product.name vivo_1902