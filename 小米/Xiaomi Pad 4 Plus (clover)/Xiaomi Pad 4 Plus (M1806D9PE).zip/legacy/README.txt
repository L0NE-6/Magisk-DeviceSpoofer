Xiaomi Pad 4 Plus 机型伪装 - 老系统（Android 1.x-5.x）说明
================================================

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入同目录 zip，重启生效。
2. Android 2.2-5.x：CWM / TWRP 直接刷 zip（自动改 /system/build.prop，备份 .xj_bak）。
3. Android 1.x-5.x 手动：root 终端执行
       su -c 'sh /sdcard/xj_apply.sh'     # 应用
       su -c 'sh /sdcard/xj_restore.sh'   # 还原