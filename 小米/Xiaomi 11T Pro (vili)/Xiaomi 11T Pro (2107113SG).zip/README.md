# Xiaomi 11T Pro 机型伪装（Android 1-17 适配版）

- 目标机型: Xiaomi 11T Pro
- 型号号: 2107113SG
- 代号: vili
- 品牌: Xiaomi (manufacturer=Xiaomi)
- 模块 id: xj_vili

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

getprop ro.product.model 应为 2107113SG，getprop ro.product.marketname 应为 Xiaomi 11T Pro。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| 2107113SG | Xiaomi 11T Pro 国际版 |
| 2107113SI | Xiaomi 11T Pro 印度版 |
| 2107113SR | Xiaomi 11T Pro 日本版 |