# Xiaomi MIX 2 机型伪装（Android 1-17 适配版）

- 目标机型: Xiaomi MIX 2
- 型号号: MDE5
- 代号: chiron
- 品牌: Xiaomi (manufacturer=Xiaomi)
- 模块 id: xj_chiron

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 MDE5，getprop ro.product.marketname 应为 Xiaomi MIX 2。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| MDE5 | 小米 MIX 2 黑色陶瓷版 全网通版 |
| MDT5 | 小米 MIX 2 黑色陶瓷版 移动 4G+ 版 |
| MDE5S | 小米 MIX 2 全陶瓷尊享版 |