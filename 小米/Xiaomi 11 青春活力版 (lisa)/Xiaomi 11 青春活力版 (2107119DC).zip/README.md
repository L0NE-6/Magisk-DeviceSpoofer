# Xiaomi 11 青春活力版 机型伪装（Android 1-17 适配版）

- 目标机型: Xiaomi 11 青春活力版
- 型号号: 2107119DC
- 代号: lisa
- 品牌: Xiaomi (manufacturer=Xiaomi)
- 模块 id: xj_lisa

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 2107119DC，getprop ro.product.marketname 应为 Xiaomi 11 青春活力版。

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| 2107119DC | Xiaomi 11 青春活力版 国行版 |
| 2109119DG | Xiaomi 11 Lite 5G NE 国际版 |
| 2109119DI | Xiaomi 11 Lite NE 5G 印度版 |