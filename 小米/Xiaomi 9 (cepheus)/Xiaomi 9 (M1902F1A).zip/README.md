# Xiaomi 9 机型伪装（Android 1-17 适配版）

- 目标机型: Xiaomi 9
- 型号号: M1902F1A
- 代号: cepheus
- 品牌: Xiaomi (manufacturer=Xiaomi)
- 模块 id: xj_cepheus

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

getprop ro.product.model 应为 M1902F1A，getprop ro.product.marketname 应为 Xiaomi 9。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| M1902F1A | 小米 9 全网通版 |
| M1902F1T | 小米 9 移动 4G+ 版 |
| M1902F1C | 小米 9 联通电信定制版 |
| M1902F1G | 小米 9 国际版 |