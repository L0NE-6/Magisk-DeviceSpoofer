# 酷派大神 F2 机型伪装（Android 1-17 适配版）

- 目标机型: 酷派大神 F2
- 型号号: 8675-HD
- 代号: 8675-hd
- 品牌: Coolpad (manufacturer=Coolpad)
- 模块 id: xj_8675-hd

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 8675-HD，getprop ro.product.marketname 应为 酷派大神 F2。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| 8675-HD | 酷派大神 F2 移动版 |
| 8675-W00 | 酷派大神 F2 联通版 |
| 8675A | 酷派大神 F2 全网通版 |
| 8675-FHD | 酷派大神 F2 全高清版 |
| 8675-F01 | 酷派大神 F2 全高清移动版​​ |
| 8690 | 酷派大神 X7 双网通版 |
| 8690-T00 | 酷派大神 X7 移动版 |
| 8691 | 酷派大神 X7 全网通版 |