#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "Coolpad"
	set_prop "ro.product.system.brand" "Coolpad"
	set_prop "ro.product.system.marketname" "酷派大观 C60"
	set_prop "ro.product.system.model" "CP3AT5"
	set_prop "ro.product.system.name" "cp3at5"
	set_prop "ro.product.system_ext.manufacturer" "Coolpad"
	set_prop "ro.product.system_ext.brand" "Coolpad"
	set_prop "ro.product.system_ext.marketname" "酷派大观 C60"
	set_prop "ro.product.system_ext.model" "CP3AT5"
	set_prop "ro.product.system_ext.name" "cp3at5"
	set_prop "ro.product.vendor.manufacturer" "Coolpad"
	set_prop "ro.product.vendor.brand" "Coolpad"
	set_prop "ro.product.vendor.marketname" "酷派大观 C60"
	set_prop "ro.product.vendor.model" "CP3AT5"
	set_prop "ro.product.vendor.name" "cp3at5"
	set_prop "ro.product.product.manufacturer" "Coolpad"
	set_prop "ro.product.product.brand" "Coolpad"
	set_prop "ro.product.product.marketname" "酷派大观 C60"
	set_prop "ro.product.product.model" "CP3AT5"
	set_prop "ro.product.product.name" "cp3at5"
	set_prop "ro.product.odm.manufacturer" "Coolpad"
	set_prop "ro.product.odm.brand" "Coolpad"
	set_prop "ro.product.odm.marketname" "酷派大观 C60"
	set_prop "ro.product.odm.model" "CP3AT5"
	set_prop "ro.product.odm.name" "cp3at5"
	set_prop "ro.product.bootimage.manufacturer" "Coolpad"
	set_prop "ro.product.bootimage.brand" "Coolpad"
	set_prop "ro.product.bootimage.marketname" "酷派大观 C60"
	set_prop "ro.product.bootimage.model" "CP3AT5"
	set_prop "ro.product.bootimage.name" "cp3at5"
	set_prop "ro.product.vendor_dlkm.manufacturer" "Coolpad"
	set_prop "ro.product.vendor_dlkm.brand" "Coolpad"
	set_prop "ro.product.vendor_dlkm.marketname" "酷派大观 C60"
	set_prop "ro.product.vendor_dlkm.model" "CP3AT5"
	set_prop "ro.product.vendor_dlkm.name" "cp3at5"
	set_prop "ro.product.odm_dlkm.manufacturer" "Coolpad"
	set_prop "ro.product.odm_dlkm.brand" "Coolpad"
	set_prop "ro.product.odm_dlkm.marketname" "酷派大观 C60"
	set_prop "ro.product.odm_dlkm.model" "CP3AT5"
	set_prop "ro.product.odm_dlkm.name" "cp3at5"
set_prop ro.product.manufacturer Coolpad
set_prop ro.product.brand Coolpad
set_prop ro.product.marketname "酷派大观 C60"
set_prop ro.product.model CP3AT5
set_prop ro.product.name cp3at5