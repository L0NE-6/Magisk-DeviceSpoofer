# 荣耀平板 机型伪装（Android 1-17 适配版）

- 目标机型: 荣耀平板
- 型号号: S8-701w
- 代号: s8-701w
- 品牌: HONOR (manufacturer=HONOR)
- 模块 id: xj_s8-701w

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 S8-701w，getprop ro.product.marketname 应为 荣耀平板。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| S8-701w | 荣耀平板 Wi-Fi 版 |
| S8-701u | 荣耀平板 3G 版 |
| T1-821w | 荣耀平板优享版 |
| T1-823L | 荣耀平板 LTE 版 |