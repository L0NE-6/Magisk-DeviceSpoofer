#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "HONOR"
	set_prop "ro.product.system.brand" "HONOR"
	set_prop "ro.product.system.marketname" "荣耀 WIN RT2"
	set_prop "ro.product.system.model" "BRT-AN00"
	set_prop "ro.product.system.name" "Barrett"
	set_prop "ro.product.system_ext.manufacturer" "HONOR"
	set_prop "ro.product.system_ext.brand" "HONOR"
	set_prop "ro.product.system_ext.marketname" "荣耀 WIN RT2"
	set_prop "ro.product.system_ext.model" "BRT-AN00"
	set_prop "ro.product.system_ext.name" "Barrett"
	set_prop "ro.product.vendor.manufacturer" "HONOR"
	set_prop "ro.product.vendor.brand" "HONOR"
	set_prop "ro.product.vendor.marketname" "荣耀 WIN RT2"
	set_prop "ro.product.vendor.model" "BRT-AN00"
	set_prop "ro.product.vendor.name" "Barrett"
	set_prop "ro.product.product.manufacturer" "HONOR"
	set_prop "ro.product.product.brand" "HONOR"
	set_prop "ro.product.product.marketname" "荣耀 WIN RT2"
	set_prop "ro.product.product.model" "BRT-AN00"
	set_prop "ro.product.product.name" "Barrett"
	set_prop "ro.product.odm.manufacturer" "HONOR"
	set_prop "ro.product.odm.brand" "HONOR"
	set_prop "ro.product.odm.marketname" "荣耀 WIN RT2"
	set_prop "ro.product.odm.model" "BRT-AN00"
	set_prop "ro.product.odm.name" "Barrett"
	set_prop "ro.product.bootimage.manufacturer" "HONOR"
	set_prop "ro.product.bootimage.brand" "HONOR"
	set_prop "ro.product.bootimage.marketname" "荣耀 WIN RT2"
	set_prop "ro.product.bootimage.model" "BRT-AN00"
	set_prop "ro.product.bootimage.name" "Barrett"
	set_prop "ro.product.vendor_dlkm.manufacturer" "HONOR"
	set_prop "ro.product.vendor_dlkm.brand" "HONOR"
	set_prop "ro.product.vendor_dlkm.marketname" "荣耀 WIN RT2"
	set_prop "ro.product.vendor_dlkm.model" "BRT-AN00"
	set_prop "ro.product.vendor_dlkm.name" "Barrett"
	set_prop "ro.product.odm_dlkm.manufacturer" "HONOR"
	set_prop "ro.product.odm_dlkm.brand" "HONOR"
	set_prop "ro.product.odm_dlkm.marketname" "荣耀 WIN RT2"
	set_prop "ro.product.odm_dlkm.model" "BRT-AN00"
	set_prop "ro.product.odm_dlkm.name" "Barrett"
set_prop ro.product.manufacturer HONOR
set_prop ro.product.brand HONOR
set_prop ro.product.marketname "荣耀 WIN RT2"
set_prop ro.product.model BRT-AN00
set_prop ro.product.name Barrett