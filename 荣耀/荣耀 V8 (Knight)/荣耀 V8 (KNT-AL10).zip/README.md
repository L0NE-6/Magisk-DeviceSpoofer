# 荣耀 V8 机型伪装（Android 1-17 适配版）

- 目标机型: 荣耀 V8
- 型号号: KNT-AL10
- 代号: Knight
- 品牌: HONOR (manufacturer=HONOR)
- 模块 id: xj_knight_2

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

getprop ro.product.model 应为 KNT-AL10，getprop ro.product.marketname 应为 荣耀 V8。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| KNT-AL10 | 荣耀 V8 全网通版 |
| KNT-AL20 | 荣耀 V8 全网通版 (麒麟 955, 2K 显示屏) |
| KNT-TL10 | 荣耀 V8 移动版 |
| KNT-UL10 | 荣耀 V8 移动/联通版 |