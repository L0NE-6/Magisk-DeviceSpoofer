#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "nubia"
	set_prop "ro.product.system.brand" "nubia"
	set_prop "ro.product.system.marketname" "nubia Z50S Pro"
	set_prop "ro.product.system.model" "NX713J"
	set_prop "ro.product.system.name" "nx713j"
	set_prop "ro.product.system_ext.manufacturer" "nubia"
	set_prop "ro.product.system_ext.brand" "nubia"
	set_prop "ro.product.system_ext.marketname" "nubia Z50S Pro"
	set_prop "ro.product.system_ext.model" "NX713J"
	set_prop "ro.product.system_ext.name" "nx713j"
	set_prop "ro.product.vendor.manufacturer" "nubia"
	set_prop "ro.product.vendor.brand" "nubia"
	set_prop "ro.product.vendor.marketname" "nubia Z50S Pro"
	set_prop "ro.product.vendor.model" "NX713J"
	set_prop "ro.product.vendor.name" "nx713j"
	set_prop "ro.product.product.manufacturer" "nubia"
	set_prop "ro.product.product.brand" "nubia"
	set_prop "ro.product.product.marketname" "nubia Z50S Pro"
	set_prop "ro.product.product.model" "NX713J"
	set_prop "ro.product.product.name" "nx713j"
	set_prop "ro.product.odm.manufacturer" "nubia"
	set_prop "ro.product.odm.brand" "nubia"
	set_prop "ro.product.odm.marketname" "nubia Z50S Pro"
	set_prop "ro.product.odm.model" "NX713J"
	set_prop "ro.product.odm.name" "nx713j"
	set_prop "ro.product.bootimage.manufacturer" "nubia"
	set_prop "ro.product.bootimage.brand" "nubia"
	set_prop "ro.product.bootimage.marketname" "nubia Z50S Pro"
	set_prop "ro.product.bootimage.model" "NX713J"
	set_prop "ro.product.bootimage.name" "nx713j"
	set_prop "ro.product.vendor_dlkm.manufacturer" "nubia"
	set_prop "ro.product.vendor_dlkm.brand" "nubia"
	set_prop "ro.product.vendor_dlkm.marketname" "nubia Z50S Pro"
	set_prop "ro.product.vendor_dlkm.model" "NX713J"
	set_prop "ro.product.vendor_dlkm.name" "nx713j"
	set_prop "ro.product.odm_dlkm.manufacturer" "nubia"
	set_prop "ro.product.odm_dlkm.brand" "nubia"
	set_prop "ro.product.odm_dlkm.marketname" "nubia Z50S Pro"
	set_prop "ro.product.odm_dlkm.model" "NX713J"
	set_prop "ro.product.odm_dlkm.name" "nx713j"
set_prop ro.product.manufacturer nubia
set_prop ro.product.brand nubia
set_prop ro.product.marketname "nubia Z50S Pro"
set_prop ro.product.model NX713J
set_prop ro.product.name nx713j