# nubia Z9 mini 机型伪装（Android 1-17 适配版）

- 目标机型: nubia Z9 mini
- 型号号: NX511J
- 代号: nx511j
- 品牌: nubia (manufacturer=nubia)
- 模块 id: xj_nx511j

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 NX511J，getprop ro.product.marketname 应为 nubia Z9 mini。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| NX511J | nubia Z9 mini 全网通版 |
| NX511H | nubia Z9 mini 双 4G 版 |