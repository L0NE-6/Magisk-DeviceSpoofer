#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "ZTE"
	set_prop "ro.product.system.brand" "ZTE"
	set_prop "ro.product.system.marketname" "中兴天机 Axon M"
	set_prop "ro.product.system.model" "Z999"
	set_prop "ro.product.system.name" "z999"
	set_prop "ro.product.system_ext.manufacturer" "ZTE"
	set_prop "ro.product.system_ext.brand" "ZTE"
	set_prop "ro.product.system_ext.marketname" "中兴天机 Axon M"
	set_prop "ro.product.system_ext.model" "Z999"
	set_prop "ro.product.system_ext.name" "z999"
	set_prop "ro.product.vendor.manufacturer" "ZTE"
	set_prop "ro.product.vendor.brand" "ZTE"
	set_prop "ro.product.vendor.marketname" "中兴天机 Axon M"
	set_prop "ro.product.vendor.model" "Z999"
	set_prop "ro.product.vendor.name" "z999"
	set_prop "ro.product.product.manufacturer" "ZTE"
	set_prop "ro.product.product.brand" "ZTE"
	set_prop "ro.product.product.marketname" "中兴天机 Axon M"
	set_prop "ro.product.product.model" "Z999"
	set_prop "ro.product.product.name" "z999"
	set_prop "ro.product.odm.manufacturer" "ZTE"
	set_prop "ro.product.odm.brand" "ZTE"
	set_prop "ro.product.odm.marketname" "中兴天机 Axon M"
	set_prop "ro.product.odm.model" "Z999"
	set_prop "ro.product.odm.name" "z999"
	set_prop "ro.product.bootimage.manufacturer" "ZTE"
	set_prop "ro.product.bootimage.brand" "ZTE"
	set_prop "ro.product.bootimage.marketname" "中兴天机 Axon M"
	set_prop "ro.product.bootimage.model" "Z999"
	set_prop "ro.product.bootimage.name" "z999"
	set_prop "ro.product.vendor_dlkm.manufacturer" "ZTE"
	set_prop "ro.product.vendor_dlkm.brand" "ZTE"
	set_prop "ro.product.vendor_dlkm.marketname" "中兴天机 Axon M"
	set_prop "ro.product.vendor_dlkm.model" "Z999"
	set_prop "ro.product.vendor_dlkm.name" "z999"
	set_prop "ro.product.odm_dlkm.manufacturer" "ZTE"
	set_prop "ro.product.odm_dlkm.brand" "ZTE"
	set_prop "ro.product.odm_dlkm.marketname" "中兴天机 Axon M"
	set_prop "ro.product.odm_dlkm.model" "Z999"
	set_prop "ro.product.odm_dlkm.name" "z999"
set_prop ro.product.manufacturer ZTE
set_prop ro.product.brand ZTE
set_prop ro.product.marketname "中兴天机 Axon M"
set_prop ro.product.model Z999
set_prop ro.product.name z999