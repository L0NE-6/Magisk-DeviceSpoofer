#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "Xiaomi"
	set_prop "ro.product.system.brand" "POCO"
	set_prop "ro.product.system.marketname" "POCO X3 Pro"
	set_prop "ro.product.system.model" "M2102J20SG"
	set_prop "ro.product.system.name" "vayu"
	set_prop "ro.product.system_ext.manufacturer" "Xiaomi"
	set_prop "ro.product.system_ext.brand" "POCO"
	set_prop "ro.product.system_ext.marketname" "POCO X3 Pro"
	set_prop "ro.product.system_ext.model" "M2102J20SG"
	set_prop "ro.product.system_ext.name" "vayu"
	set_prop "ro.product.vendor.manufacturer" "Xiaomi"
	set_prop "ro.product.vendor.brand" "POCO"
	set_prop "ro.product.vendor.marketname" "POCO X3 Pro"
	set_prop "ro.product.vendor.model" "M2102J20SG"
	set_prop "ro.product.vendor.name" "vayu"
	set_prop "ro.product.product.manufacturer" "Xiaomi"
	set_prop "ro.product.product.brand" "POCO"
	set_prop "ro.product.product.marketname" "POCO X3 Pro"
	set_prop "ro.product.product.model" "M2102J20SG"
	set_prop "ro.product.product.name" "vayu"
	set_prop "ro.product.odm.manufacturer" "Xiaomi"
	set_prop "ro.product.odm.brand" "POCO"
	set_prop "ro.product.odm.marketname" "POCO X3 Pro"
	set_prop "ro.product.odm.model" "M2102J20SG"
	set_prop "ro.product.odm.name" "vayu"
	set_prop "ro.product.bootimage.manufacturer" "Xiaomi"
	set_prop "ro.product.bootimage.brand" "POCO"
	set_prop "ro.product.bootimage.marketname" "POCO X3 Pro"
	set_prop "ro.product.bootimage.model" "M2102J20SG"
	set_prop "ro.product.bootimage.name" "vayu"
	set_prop "ro.product.vendor_dlkm.manufacturer" "Xiaomi"
	set_prop "ro.product.vendor_dlkm.brand" "POCO"
	set_prop "ro.product.vendor_dlkm.marketname" "POCO X3 Pro"
	set_prop "ro.product.vendor_dlkm.model" "M2102J20SG"
	set_prop "ro.product.vendor_dlkm.name" "vayu"
	set_prop "ro.product.odm_dlkm.manufacturer" "Xiaomi"
	set_prop "ro.product.odm_dlkm.brand" "POCO"
	set_prop "ro.product.odm_dlkm.marketname" "POCO X3 Pro"
	set_prop "ro.product.odm_dlkm.model" "M2102J20SG"
	set_prop "ro.product.odm_dlkm.name" "vayu"
set_prop ro.product.manufacturer Xiaomi
set_prop ro.product.brand POCO
set_prop ro.product.marketname "POCO X3 Pro"
set_prop ro.product.model M2102J20SG
set_prop ro.product.name vayu