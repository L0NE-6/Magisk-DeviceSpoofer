# Pixel 10 Pro Fold 机型伪装（Android 1-17 适配版）

- 目标机型: Pixel 10 Pro Fold
- 型号号: GU0NP
- 代号: rango
- 品牌: google (manufacturer=Google)
- 模块 id: xj_rango

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 GU0NP，getprop ro.product.marketname 应为 Pixel 10 Pro Fold。

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| GU0NP | Pixel 10 Pro Fold (Global) |
| GM66V | Pixel 10 Pro Fold (Japan) |