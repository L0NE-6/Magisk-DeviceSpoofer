# Pixel 3a 机型伪装（Android 1-17 适配版）

- 目标机型: Pixel 3a
- 型号号: G020E
- 代号: sargo
- 品牌: google (manufacturer=Google)
- 模块 id: xj_sargo

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 G020E，getprop ro.product.marketname 应为 Pixel 3a。

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

## 关注作者

- 安装完成后会自动打开作者酷安主页：装有酷安 App 直接跳转，未安装则用浏览器打开；
- 之后可以随时在 KernelSU / APatch 管理器的模块卡片点「执行」按钮再次打开；
- 酷安主页：https://www.coolapk.com/u/1429422

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| G020E | Pixel 3a (Verizon) |
| G020F | Pixel 3a (UK, Europe, and APAC) |
| G020G | Pixel 3a (North America) |
| G020H | Pixel 3a (Japan) |