# ROG Phone 6D 机型伪装（Android 1-17 适配版）

- 目标机型: ROG Phone 6D
- 型号号: ASUS_AI2203_C
- 代号: AI2203
- 品牌: ASUS (manufacturer=ASUSTeK)
- 模块 id: xj_ai2203

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 ASUS_AI2203_C，getprop ro.product.marketname 应为 ROG Phone 6D。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| ASUS_AI2203_C | ROG Phone 6D |
| ASUS_AI2203_D | ROG Phone 6D Ultimate |