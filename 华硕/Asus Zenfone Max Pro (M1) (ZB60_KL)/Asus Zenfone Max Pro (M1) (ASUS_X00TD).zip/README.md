# Asus Zenfone Max Pro (M1) 机型伪装（Android 1-17 适配版）

- 目标机型: Asus Zenfone Max Pro (M1)
- 型号号: ASUS_X00TD
- 代号: ZB60*KL
- 品牌: ASUS (manufacturer=ASUSTeK)
- 模块 id: xj_zb60_kl

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 ASUS_X00TD，getprop ro.product.marketname 应为 Asus Zenfone Max Pro (M1)。

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| ASUS_X00TD | Asus ZenFone Max Pro (M1) (ZB601KL) |
| ASUS_X00TD | Asus ZenFone Max Pro (M1) (ZB602KL) |