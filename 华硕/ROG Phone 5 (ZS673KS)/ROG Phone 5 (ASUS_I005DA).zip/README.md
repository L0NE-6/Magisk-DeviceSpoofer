# ROG Phone 5 机型伪装（Android 1-17 适配版）

- 目标机型: ROG Phone 5
- 型号号: ASUS_I005DA
- 代号: ZS673KS
- 品牌: ASUS (manufacturer=ASUSTeK)
- 模块 id: xj_zs673ks

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 ASUS_I005DA，getprop ro.product.marketname 应为 ROG Phone 5。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| ASUS_I005DA | ROG Phone 5 |
| ASUS_I005DB | ROG Phone 5 Pro |