#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "ASUSTeK"
	set_prop "ro.product.system.brand" "ASUS"
	set_prop "ro.product.system.marketname" "Asus Zenfone 12 Ultra"
	set_prop "ro.product.system.model" "ASUSAI2501H"
	set_prop "ro.product.system.name" "AI2501_H"
	set_prop "ro.product.system_ext.manufacturer" "ASUSTeK"
	set_prop "ro.product.system_ext.brand" "ASUS"
	set_prop "ro.product.system_ext.marketname" "Asus Zenfone 12 Ultra"
	set_prop "ro.product.system_ext.model" "ASUSAI2501H"
	set_prop "ro.product.system_ext.name" "AI2501_H"
	set_prop "ro.product.vendor.manufacturer" "ASUSTeK"
	set_prop "ro.product.vendor.brand" "ASUS"
	set_prop "ro.product.vendor.marketname" "Asus Zenfone 12 Ultra"
	set_prop "ro.product.vendor.model" "ASUSAI2501H"
	set_prop "ro.product.vendor.name" "AI2501_H"
	set_prop "ro.product.product.manufacturer" "ASUSTeK"
	set_prop "ro.product.product.brand" "ASUS"
	set_prop "ro.product.product.marketname" "Asus Zenfone 12 Ultra"
	set_prop "ro.product.product.model" "ASUSAI2501H"
	set_prop "ro.product.product.name" "AI2501_H"
	set_prop "ro.product.odm.manufacturer" "ASUSTeK"
	set_prop "ro.product.odm.brand" "ASUS"
	set_prop "ro.product.odm.marketname" "Asus Zenfone 12 Ultra"
	set_prop "ro.product.odm.model" "ASUSAI2501H"
	set_prop "ro.product.odm.name" "AI2501_H"
	set_prop "ro.product.bootimage.manufacturer" "ASUSTeK"
	set_prop "ro.product.bootimage.brand" "ASUS"
	set_prop "ro.product.bootimage.marketname" "Asus Zenfone 12 Ultra"
	set_prop "ro.product.bootimage.model" "ASUSAI2501H"
	set_prop "ro.product.bootimage.name" "AI2501_H"
	set_prop "ro.product.vendor_dlkm.manufacturer" "ASUSTeK"
	set_prop "ro.product.vendor_dlkm.brand" "ASUS"
	set_prop "ro.product.vendor_dlkm.marketname" "Asus Zenfone 12 Ultra"
	set_prop "ro.product.vendor_dlkm.model" "ASUSAI2501H"
	set_prop "ro.product.vendor_dlkm.name" "AI2501_H"
	set_prop "ro.product.odm_dlkm.manufacturer" "ASUSTeK"
	set_prop "ro.product.odm_dlkm.brand" "ASUS"
	set_prop "ro.product.odm_dlkm.marketname" "Asus Zenfone 12 Ultra"
	set_prop "ro.product.odm_dlkm.model" "ASUSAI2501H"
	set_prop "ro.product.odm_dlkm.name" "AI2501_H"
set_prop ro.product.manufacturer ASUSTeK
set_prop ro.product.brand ASUS
set_prop ro.product.marketname "Asus Zenfone 12 Ultra"
set_prop ro.product.model ASUSAI2501H
set_prop ro.product.name AI2501_H