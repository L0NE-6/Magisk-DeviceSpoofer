#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "Xiaomi"
	set_prop "ro.product.system.brand" "Redmi"
	set_prop "ro.product.system.marketname" "Redmi A2+"
	set_prop "ro.product.system.model" "23028RNCAG"
	set_prop "ro.product.system.name" "water"
	set_prop "ro.product.system_ext.manufacturer" "Xiaomi"
	set_prop "ro.product.system_ext.brand" "Redmi"
	set_prop "ro.product.system_ext.marketname" "Redmi A2+"
	set_prop "ro.product.system_ext.model" "23028RNCAG"
	set_prop "ro.product.system_ext.name" "water"
	set_prop "ro.product.vendor.manufacturer" "Xiaomi"
	set_prop "ro.product.vendor.brand" "Redmi"
	set_prop "ro.product.vendor.marketname" "Redmi A2+"
	set_prop "ro.product.vendor.model" "23028RNCAG"
	set_prop "ro.product.vendor.name" "water"
	set_prop "ro.product.product.manufacturer" "Xiaomi"
	set_prop "ro.product.product.brand" "Redmi"
	set_prop "ro.product.product.marketname" "Redmi A2+"
	set_prop "ro.product.product.model" "23028RNCAG"
	set_prop "ro.product.product.name" "water"
	set_prop "ro.product.odm.manufacturer" "Xiaomi"
	set_prop "ro.product.odm.brand" "Redmi"
	set_prop "ro.product.odm.marketname" "Redmi A2+"
	set_prop "ro.product.odm.model" "23028RNCAG"
	set_prop "ro.product.odm.name" "water"
	set_prop "ro.product.bootimage.manufacturer" "Xiaomi"
	set_prop "ro.product.bootimage.brand" "Redmi"
	set_prop "ro.product.bootimage.marketname" "Redmi A2+"
	set_prop "ro.product.bootimage.model" "23028RNCAG"
	set_prop "ro.product.bootimage.name" "water"
	set_prop "ro.product.vendor_dlkm.manufacturer" "Xiaomi"
	set_prop "ro.product.vendor_dlkm.brand" "Redmi"
	set_prop "ro.product.vendor_dlkm.marketname" "Redmi A2+"
	set_prop "ro.product.vendor_dlkm.model" "23028RNCAG"
	set_prop "ro.product.vendor_dlkm.name" "water"
	set_prop "ro.product.odm_dlkm.manufacturer" "Xiaomi"
	set_prop "ro.product.odm_dlkm.brand" "Redmi"
	set_prop "ro.product.odm_dlkm.marketname" "Redmi A2+"
	set_prop "ro.product.odm_dlkm.model" "23028RNCAG"
	set_prop "ro.product.odm_dlkm.name" "water"
set_prop ro.product.manufacturer Xiaomi
set_prop ro.product.brand Redmi
set_prop ro.product.marketname "Redmi A2+"
set_prop ro.product.model 23028RNCAG
set_prop ro.product.name water