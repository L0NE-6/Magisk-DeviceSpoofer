# Redmi 4A 机型伪装（Android 1-17 适配版）

- 目标机型: Redmi 4A
- 型号号: 2016111
- 代号: rolex
- 品牌: Redmi (manufacturer=Xiaomi)
- 模块 id: xj_rolex

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

getprop ro.product.model 应为 2016111，getprop ro.product.marketname 应为 Redmi 4A。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| 2016111 | 红米 4A 全网通版 |
| 2016112 | 红米 4A 移动 4G+ 版 |
| 2016117 | 红米 4A 国际版 |
| 2016116 | 红米 4A 印度版 |