# Redmi 10 2022 (`selene`) 机型伪装（Android 1-17 适配版）

- 目标机型: Redmi 10 2022 (`selene`)
- 型号号: 22011119UY
- 代号: eos
- 品牌: Redmi (manufacturer=Xiaomi)
- 模块 id: xj_eos_2

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 22011119UY，getprop ro.product.marketname 应为 Redmi 10 2022 (`selene`)。

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| 22011119UY | Redmi 10 2022 国际版 (NFC) |