# Redmi Pad Pro 5G 机型伪装（Android 1-17 适配版）

- 目标机型: Redmi Pad Pro 5G
- 型号号: 24074RPD2C
- 代号: ruan
- 品牌: Redmi (manufacturer=Xiaomi)
- 模块 id: xj_ruan

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 24074RPD2C，getprop ro.product.marketname 应为 Redmi Pad Pro 5G。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| 24074RPD2C | Redmi Pad Pro 5G 国行版 |
| 24074RPD2G | Redmi Pad Pro 5G 国际版 |
| 24074RPD2I | Redmi Pad Pro 5G 印度版 |