# REDMI Note 15 机型伪装（Android 1-17 适配版）

- 目标机型: REDMI Note 15
- 型号号: 2510DRA23G
- 代号: spinel
- 品牌: Redmi (manufacturer=Xiaomi)
- 模块 id: xj_spinel

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 2510DRA23G，getprop ro.product.marketname 应为 REDMI Note 15。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| 2510DRA23G | REDMI Note 15 国际版 |
| 2510DRA23E | REDMI Note 15 欧洲版 |
| 2510DRA23L | REDMI Note 15 拉美版 |