# Redmi Note 7 机型伪装（Android 1-17 适配版）

- 目标机型: Redmi Note 7
- 型号号: M1901F7E
- 代号: lavender
- 品牌: Redmi (manufacturer=Xiaomi)
- 模块 id: xj_lavender

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 M1901F7E，getprop ro.product.marketname 应为 Redmi Note 7。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| M1901F7E | Redmi Note 7 全网通版 |
| M1901F7T | Redmi Note 7 移动 4G+ 版 |
| M1901F7C | Redmi Note 7 联通电信定制版 |
| M1901F7I | Redmi Note 7 印度版 / Redmi Note 7S 印度版 |