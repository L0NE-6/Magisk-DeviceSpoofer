# Redmi Note 5A 机型伪装（Android 1-17 适配版）

- 目标机型: Redmi Note 5A
- 型号号: MDE6S
- 代号: ugg
- 品牌: Redmi (manufacturer=Xiaomi)
- 模块 id: xj_ugg

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 MDE6S，getprop ro.product.marketname 应为 Redmi Note 5A。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| MDE6S | 红米 Note 5A 全网通 高配版 |
| MDT6S | 红米 Note 5A 移动 4G+ 高配版 |
| MDG6S | 红米 Note 5A 国际版 高配版 |
| MDI6S | 红米 Y1 印度版 |