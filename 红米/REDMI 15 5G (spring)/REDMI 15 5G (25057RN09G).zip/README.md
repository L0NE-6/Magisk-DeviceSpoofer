# REDMI 15 5G 机型伪装（Android 1-17 适配版）

- 目标机型: REDMI 15 5G
- 型号号: 25057RN09G
- 代号: spring
- 品牌: Redmi (manufacturer=Xiaomi)
- 模块 id: xj_spring

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 25057RN09G，getprop ro.product.marketname 应为 REDMI 15 5G。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| 25057RN09G | REDMI 15 5G 国际版 |
| 25057RN09E | REDMI 15 5G 欧洲版 |
| 25057RN09I | REDMI 15 5G 印度版 |
| 25057RN09R | REDMI 15 5G 日本版 (无锁) |
| A501XM | REDMI 15 5G 日本版 (SoftBank) |