# Redmi 14C 机型伪装（Android 1-17 适配版）

- 目标机型: Redmi 14C
- 型号号: 2409BRN2CC
- 代号: pond
- 品牌: Redmi (manufacturer=Xiaomi)
- 模块 id: xj_pond

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 2409BRN2CC，getprop ro.product.marketname 应为 Redmi 14C。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| 2409BRN2CC | Redmi 14C 国行版 / REDMI 17C 国行版 |
| 2409BRN2CA | Redmi 14C 国际版 |
| 2409BRN2CI | Redmi 14C 印度版 |
| 2409BRN2CL | Redmi 14C 拉美版 / 日韩版 |