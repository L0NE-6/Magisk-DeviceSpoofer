# REDMI Pad 2 机型伪装（Android 1-17 适配版）

- 目标机型: REDMI Pad 2
- 型号号: 25040RP0AC
- 代号: taiko
- 品牌: Redmi (manufacturer=Xiaomi)
- 模块 id: xj_taiko

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 25040RP0AC，getprop ro.product.marketname 应为 REDMI Pad 2。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| 25040RP0AC | REDMI Pad 2 国行版 |
| 25040RP0AG | REDMI Pad 2 国际版 |
| 25040RP0AI | REDMI Pad 2 印度版 |
| 25040RP0AE | REDMI Pad 2 欧洲版 |
| 25040RP0AL | REDMI Pad 2 拉美版 |