# Redmi Pad Pro 机型伪装（Android 1-17 适配版）

- 目标机型: Redmi Pad Pro
- 型号号: 2405CRPFDC
- 代号: dizi
- 品牌: Redmi (manufacturer=Xiaomi)
- 模块 id: xj_dizi

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 2405CRPFDC，getprop ro.product.marketname 应为 Redmi Pad Pro。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| 2405CRPFDC | Redmi Pad Pro Wi-Fi 国行版 |
| 2405CRPFDG | Redmi Pad Pro Wi-Fi 国际版 |
| 2405CRPFDI | Redmi Pad Pro Wi-Fi 印度版 |
| 2405CRPFDL | Redmi Pad Pro Wi-Fi 拉美版 / 韩国版 |