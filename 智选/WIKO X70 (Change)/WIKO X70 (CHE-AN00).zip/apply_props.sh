#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "智选"
	set_prop "ro.product.system.brand" "智选"
	set_prop "ro.product.system.marketname" "WIKO X70"
	set_prop "ro.product.system.model" "CHE-AN00"
	set_prop "ro.product.system.name" "Change"
	set_prop "ro.product.system_ext.manufacturer" "智选"
	set_prop "ro.product.system_ext.brand" "智选"
	set_prop "ro.product.system_ext.marketname" "WIKO X70"
	set_prop "ro.product.system_ext.model" "CHE-AN00"
	set_prop "ro.product.system_ext.name" "Change"
	set_prop "ro.product.vendor.manufacturer" "智选"
	set_prop "ro.product.vendor.brand" "智选"
	set_prop "ro.product.vendor.marketname" "WIKO X70"
	set_prop "ro.product.vendor.model" "CHE-AN00"
	set_prop "ro.product.vendor.name" "Change"
	set_prop "ro.product.product.manufacturer" "智选"
	set_prop "ro.product.product.brand" "智选"
	set_prop "ro.product.product.marketname" "WIKO X70"
	set_prop "ro.product.product.model" "CHE-AN00"
	set_prop "ro.product.product.name" "Change"
	set_prop "ro.product.odm.manufacturer" "智选"
	set_prop "ro.product.odm.brand" "智选"
	set_prop "ro.product.odm.marketname" "WIKO X70"
	set_prop "ro.product.odm.model" "CHE-AN00"
	set_prop "ro.product.odm.name" "Change"
	set_prop "ro.product.bootimage.manufacturer" "智选"
	set_prop "ro.product.bootimage.brand" "智选"
	set_prop "ro.product.bootimage.marketname" "WIKO X70"
	set_prop "ro.product.bootimage.model" "CHE-AN00"
	set_prop "ro.product.bootimage.name" "Change"
	set_prop "ro.product.vendor_dlkm.manufacturer" "智选"
	set_prop "ro.product.vendor_dlkm.brand" "智选"
	set_prop "ro.product.vendor_dlkm.marketname" "WIKO X70"
	set_prop "ro.product.vendor_dlkm.model" "CHE-AN00"
	set_prop "ro.product.vendor_dlkm.name" "Change"
	set_prop "ro.product.odm_dlkm.manufacturer" "智选"
	set_prop "ro.product.odm_dlkm.brand" "智选"
	set_prop "ro.product.odm_dlkm.marketname" "WIKO X70"
	set_prop "ro.product.odm_dlkm.model" "CHE-AN00"
	set_prop "ro.product.odm_dlkm.name" "Change"
set_prop ro.product.manufacturer 智选
set_prop ro.product.brand 智选
set_prop ro.product.marketname "WIKO X70"
set_prop ro.product.model CHE-AN00
set_prop ro.product.name Change