# Hi nova 9 机型伪装（Android 1-17 适配版）

- 目标机型: Hi nova 9
- 型号号: Hera-BD00
- 代号: hera-bd00
- 品牌: 智选 (manufacturer=智选)
- 模块 id: xj_hera-bd00

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 Hera-BD00，getprop ro.product.marketname 应为 Hi nova 9。

## 更新

模块内置更新信息：刷入后可在 Magisk / KernelSU / APatch 管理器里直接检查并安装新版本。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| Hera-BD00 | Hi nova 9 5G |