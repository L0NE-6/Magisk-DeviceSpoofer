#!/system/bin/sh
# service：开机后再校验一次，防止系统组件或 OEM 服务回写属性
MODDIR=${0%/*}
[ -f "$MODDIR/apply_props.sh" ] && . "$MODDIR/apply_props.sh"