#!/system/bin/sh
# post-fs-data：Zygote 启动前应用，确保 Build.* 与系统服务读取到新值
MODDIR=${0%/*}
[ -f "$MODDIR/apply_props.sh" ] && . "$MODDIR/apply_props.sh"