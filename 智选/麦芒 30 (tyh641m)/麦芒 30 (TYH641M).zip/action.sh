#!/system/bin/sh

if /system/bin/pm list packages 2>/dev/null | grep -q '^package:com\.coolapk\.market$'; then
/system/bin/am start -d 'coolmarket://u/1429422' >/dev/null 2>&1
else
/system/bin/am start -a android.intent.action.VIEW -d 'https://www.coolapk.com/u/1429422' >/dev/null 2>&1
fi