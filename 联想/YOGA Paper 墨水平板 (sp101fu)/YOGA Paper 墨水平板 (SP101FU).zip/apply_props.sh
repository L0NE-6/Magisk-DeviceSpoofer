#!/system/bin/sh
# 机型属性应用脚本：由 post-fs-data.sh / service.sh 载入
# 覆盖 generic + system/system_ext/vendor/product/odm/bootimage/vendor_dlkm/odm_dlkm

RP=""
for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
	if [ -x "$c" ]; then RP="$c"; break; fi
	p="$(command -v "$c" 2>/dev/null)"
	if [ -n "$p" ] && [ -x "$p" ]; then RP="$p"; break; fi
done

get_prop() {
	if [ -n "$RP" ]; then
		"$RP" "$1" 2>/dev/null && return 0
	fi
	getprop "$1" 2>/dev/null
}

set_prop() {
	_n="$1"; _v="$2"
	[ "$(get_prop "$_n")" = "$_v" ] && return 0
	if [ -n "$RP" ]; then
		"$RP" -n "$_n" "$_v" 2>/dev/null && return 0
		_old="$(get_prop "$_n")"
		"$RP" --delete "$_n" 2>/dev/null || "$RP" -d "$_n" 2>/dev/null
		if "$RP" -n "$_n" "$_v" 2>/dev/null || "$RP" "$_n" "$_v" 2>/dev/null; then
			return 0
		fi
		[ -n "$_old" ] && "$RP" "$_n" "$_old" 2>/dev/null
	fi
	if command -v magisk >/dev/null 2>&1 && magisk resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	if command -v ksud >/dev/null 2>&1 && ksud resetprop -n "$_n" "$_v" 2>/dev/null; then
		return 0
	fi
	setprop "$_n" "$_v" 2>/dev/null
}

	set_prop "ro.product.system.manufacturer" "Lenovo"
	set_prop "ro.product.system.brand" "Lenovo"
	set_prop "ro.product.system.marketname" "YOGA Paper 墨水平板"
	set_prop "ro.product.system.model" "SP101FU"
	set_prop "ro.product.system.name" "sp101fu"
	set_prop "ro.product.system_ext.manufacturer" "Lenovo"
	set_prop "ro.product.system_ext.brand" "Lenovo"
	set_prop "ro.product.system_ext.marketname" "YOGA Paper 墨水平板"
	set_prop "ro.product.system_ext.model" "SP101FU"
	set_prop "ro.product.system_ext.name" "sp101fu"
	set_prop "ro.product.vendor.manufacturer" "Lenovo"
	set_prop "ro.product.vendor.brand" "Lenovo"
	set_prop "ro.product.vendor.marketname" "YOGA Paper 墨水平板"
	set_prop "ro.product.vendor.model" "SP101FU"
	set_prop "ro.product.vendor.name" "sp101fu"
	set_prop "ro.product.product.manufacturer" "Lenovo"
	set_prop "ro.product.product.brand" "Lenovo"
	set_prop "ro.product.product.marketname" "YOGA Paper 墨水平板"
	set_prop "ro.product.product.model" "SP101FU"
	set_prop "ro.product.product.name" "sp101fu"
	set_prop "ro.product.odm.manufacturer" "Lenovo"
	set_prop "ro.product.odm.brand" "Lenovo"
	set_prop "ro.product.odm.marketname" "YOGA Paper 墨水平板"
	set_prop "ro.product.odm.model" "SP101FU"
	set_prop "ro.product.odm.name" "sp101fu"
	set_prop "ro.product.bootimage.manufacturer" "Lenovo"
	set_prop "ro.product.bootimage.brand" "Lenovo"
	set_prop "ro.product.bootimage.marketname" "YOGA Paper 墨水平板"
	set_prop "ro.product.bootimage.model" "SP101FU"
	set_prop "ro.product.bootimage.name" "sp101fu"
	set_prop "ro.product.vendor_dlkm.manufacturer" "Lenovo"
	set_prop "ro.product.vendor_dlkm.brand" "Lenovo"
	set_prop "ro.product.vendor_dlkm.marketname" "YOGA Paper 墨水平板"
	set_prop "ro.product.vendor_dlkm.model" "SP101FU"
	set_prop "ro.product.vendor_dlkm.name" "sp101fu"
	set_prop "ro.product.odm_dlkm.manufacturer" "Lenovo"
	set_prop "ro.product.odm_dlkm.brand" "Lenovo"
	set_prop "ro.product.odm_dlkm.marketname" "YOGA Paper 墨水平板"
	set_prop "ro.product.odm_dlkm.model" "SP101FU"
	set_prop "ro.product.odm_dlkm.name" "sp101fu"
set_prop ro.product.manufacturer Lenovo
set_prop ro.product.brand Lenovo
set_prop ro.product.marketname "YOGA Paper 墨水平板"
set_prop ro.product.model SP101FU
set_prop ro.product.name sp101fu