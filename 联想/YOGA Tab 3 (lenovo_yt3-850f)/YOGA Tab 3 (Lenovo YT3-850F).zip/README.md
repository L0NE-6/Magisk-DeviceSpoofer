# YOGA Tab 3 机型伪装（Android 1-17 适配版）

- 目标机型: YOGA Tab 3
- 型号号: Lenovo YT3-850F
- 代号: lenovo_yt3-850f
- 品牌: Lenovo (manufacturer=Lenovo)
- 模块 id: xj_lenovo_yt3-850f

## 安装

1. Android 6-17：Magisk / KernelSU / APatch 管理器刷入本文件夹内的 zip，重启。
2. Android 2.2-5.x：CWM / TWRP 直接刷同一个 zip（自动改写 build.prop，先备份 .xj_bak）。
3. Android 1.x-5.x 手动：见 legacy/ 目录（xj_apply.sh / xj_restore.sh）。

## 校验

getprop ro.product.model 应为 Lenovo YT3-850F，getprop ro.product.marketname 应为 YOGA Tab 3。

## 同机型其它可用型号号（改 system.prop / apply_props.sh 即可替换）

| 型号 | 说明 |
|---|---|
| Lenovo YT3-850F | YOGA Tab 3 8” Wi-Fi 版 |
| Lenovo YT3-850L | YOGA Tab 3 8” LTE 版 |
| Lenovo YT3-X50F | YOGA Tab 3 10” Wi-Fi 版 |
| Lenovo YT3-X50L | YOGA Tab 3 10” LTE 版 |